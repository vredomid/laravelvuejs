new Vue({
    el: '#app',
    vuetify: new Vuetify(),
    data: {
        data_table_wakimart: '',
        dataNameDelete : '',
        dataEmailDelete: '',
        namedit:'',
        emailedit:'',
        productName: '',
        productPrice: '',
        dialogAdd: false,
        dialogEdit: false,
        dialogDelete: false,
        productIdEdit: '',
        productNameEdit: '',
        productEmailEdit: '',
        productIdDelete: '',
        name: '',
        email: '',
        country: '',
        city: '',
        job: '',
        namedit: '',
        emailedit: '',
        cuntryedit: '',
        cityedit: '',
        jobedit: '',
        productNameDelete: ''
        
    },
    created: function () {
        this.wakimart_data()
    },
    methods: {
 
        // Get Product
        wakimart_data: function () {
            axios.get('http://localhost:8000/api/wakimart')
                .then(res => {
                    this.data_table_wakimart = res.data;
                })
                .catch(err => {
                    // handle error
                    console.log(err);
                })
        },
 
        // Create New product
        addnew: function () {
            axios.post('http://localhost:8000/api/wakimart/store', {
                name: this.name,
                email: this.email,
                })
                .then(res => {
                    // handle success
                    this.wakimart_data();
                    this.name = '';
                    this.email = '';
                    this.dialogAdd = false;
                })
                .catch(err => {
                    // handle error
                    console.log(err);
                })
        },
 
        // Get Edit and Show data to Modal
        getEdit: function (data_wakimarts) {
            this.dialogEdit = true;
            this.id = data_wakimarts.id;
            this.namedit = data_wakimarts.name;
            this.emailedit = data_wakimarts.email;
        },
 
        // Get Delete and Show Confirm Modal
        getDelete: function (data_wakimarts) {
            this.dialogDelete = true;
            this.id = data_wakimarts.id;
            this.dataNameDelete = data_wakimarts.name;
            this.dataEmailDelete = data_wakimarts.email;
        },
 
        // Update Product
        updateProduct: function () {
            axios.put(`http://localhost:8000/api/wakimart/update/${this.id}`, {
                    name: this.namedit,
                    email: this.emailedit
                })
                .then(res => {
                    // handle success
                    this.wakimart_data();
                    this.dialogEdit = false;
                })
                .catch(err => {
                    // handle error
                    console.log(err);
                })
        },
 
        // Delete Product
        deleteProduct: function () {
            axios.delete(`http://localhost:8000/api/wakimart/${this.id}`)
                .then(res => {
                    // handle success
                    this.wakimart_data();
                    this.dialogDelete = false;
                })
                .catch(err => {
                    // handle error
                    console.log(err);
                })
        }
    }
})